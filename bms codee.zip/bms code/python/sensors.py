# sensors.py
import random
from environment import OutdoorEnvironment
from buildings import Building
from controller import BuildingController

# single shared outdoor environment instance
outdoor_env = OutdoorEnvironment()

def simulate_room_state(last_state, building_meta, current_dt, anomaly=False):
    """
    last_state: dict with keys temp, humidity, co2, light, energy, ac, vent, lights
    building_meta: dict from config (id, type, insulation, ...)
    hour: int hour of day (0-23)
    anomaly: bool flag for extra spikes
    returns new_state dict
    """
    # unpack
    btype = building_meta["type"]
    insulation = building_meta.get("insulation", 0.75)
    rooms_per = building_meta.get("rooms_per_floor", 1)

    # 1) outdoor influence
    out_temp, out_hum, out_sun = outdoor_env.step(current_dt=current_dt, anomaly=False)  # anomaly controlled outside

    # 2) occupancy (we use Building helper for pattern-based occupancy if needed)
    # here we approximate occupancy per room cluster externally; generator will pass occupancy

    # 3) controller decisions will be computed by controller module; sensors compute physical effects
    # Provide helpers for small updates (these mirror previously discussed physics)
    # Temperature influenced by outdoor, insulation, occupancy (internal gains), and AC (if on)
    # Humidity inverse to temp and influenced by outdoor humidity and ventilation
    # CO2 scales with occupancy and ventilation
    # Light = natural through windows + artificial when lights on
    # Energy derived from controller and loads

    # We'll not decide controls here; just compute physical sensor responses given inputs.
    # Expect last_state to contain: occupancy, ac, vent, lights (booleans/ints)

    occupancy = last_state.get("occupancy", 0)
    ac_on = last_state.get("ac", False)
    vent_on = last_state.get("vent", False)
    lights_on = last_state.get("lights", False)

    # Temperature: pull towards a desired indoor temp influenced by outdoor and insulation + internal gains
    internal_gain = 0.03 * occupancy  # people and equipment heat
    desired_temp = out_temp * (1 - insulation) + (22 + internal_gain) * insulation
    # if AC on, target is lower
    if ac_on:
        desired_temp -= 3.0  # AC effect
    temp = last_state["temp"] + 0.15 * (desired_temp - last_state["temp"]) + random.uniform(-0.15, 0.15)
    if anomaly:
        temp += random.uniform(3.0, 6.0)
    temp = round(max(5.0, min(45.0, temp)), 2)

    # Humidity: gravitates between outdoor humidity and internal target (inverse relation to temp)
    desired_humidity = max(5.0, min(95.0, out_hum * 0.6 + (60 - (temp - 20) * 1.0) * 0.4))
    # ventilation reduces humidity slightly when on
    if vent_on:
        desired_humidity -= 3.0
    humidity = last_state["humidity"] + 0.12 * (desired_humidity - last_state["humidity"]) + random.uniform(-0.6, 0.6)
    if anomaly:
        humidity += random.uniform(-8.0, 8.0)
    humidity = round(max(1.0, min(99.0, humidity)), 2)

    # CO2: base from occupancy, ventilation reduces it
    base_co2 = 400 + occupancy * random.uniform(8, 22)
    if vent_on:
        base_co2 = max(200, base_co2 - 200)
    co2 = last_state["co2"] + 0.25 * (base_co2 - last_state["co2"]) + random.uniform(-8, 8)
    if anomaly:
        co2 += random.uniform(150, 700)
    co2 = round(max(200.0, min(5000.0, co2)), 2)

    # Light: natural through windows + artificial if lights_on
    window_factor = 0.5  # fraction of outdoor sunlight reaching interior
    natural = out_sun * window_factor
    artificial = 400.0 if lights_on else 0.0
    desired_light = natural + artificial
    light = last_state["light"] + 0.2 * (desired_light - last_state["light"]) + random.uniform(-8, 8)
    if anomaly:
        light += random.uniform(-200, 200)
    light = round(max(0.0, min(2000.0, light)), 2)

    # Energy: basic load + AC + ventilation + lights + occupancy effect
    base_load = 0.2
    if ac_on:
        base_load += 2.2  # AC heavy
    if vent_on:
        base_load += 1.0
    if lights_on:
        base_load += 0.6
    base_load += occupancy * 0.03
    # building type scale
    scale = {"residential": 1.0, "office": 1.8, "gym": 1.6, "mall": 3.0}.get(btype, 1.0)
    energy = last_state["energy"] + 0.2 * (base_load * scale - last_state["energy"]) + random.uniform(-0.1, 0.1)
    if anomaly:
        energy += random.uniform(1.0, 4.0)
    energy = round(max(0.01, energy), 2)

    new_state = {
        "temp": temp,
        "humidity": humidity,
        "co2": co2,
        "light": light,
        "energy": energy,
        "ac": ac_on,
        "vent": vent_on,
        "lights": lights_on,
        "occupancy": occupancy
    }
    return new_state
