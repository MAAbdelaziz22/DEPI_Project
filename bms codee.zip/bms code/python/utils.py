# ======= File: utils.py =======
import csv
import os
from datetime import datetime


def ensure_dir(d):
    if not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


def ensure_csv_header(filename, header):
    exists = os.path.isfile(filename)
    if not exists:
        with open(filename, mode="w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(header)


def write_row(filename, row):
    with open(filename, mode="a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(row)

