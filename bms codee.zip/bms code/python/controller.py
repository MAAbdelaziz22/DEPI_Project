# controller.py
import random

class BuildingController:
    """
    Controls the building systems (AC, ventilation, lights)
    based on current conditions.
    """

    def __init__(self):
        self.ac_on = False
        self.ventilation_on = False
        self.lights_on = True

    def decide_controls(self, temperature, humidity, co2, sunlight, occupancy, building_type):
        
        
        if temperature > 27 and occupancy > 0:
            self.ac_on = True
        elif temperature < 23:
            self.ac_on = False

       
        if co2 > 800:
            self.ventilation_on = True
        elif co2 < 500:
            self.ventilation_on = False

        
        if sunlight > 600 and building_type != "gym":
            self.lights_on = False
        elif sunlight < 400 or building_type == "gym":
            self.lights_on = True

    def compute_energy_usage(self, occupancy):
        
        base = 0.2
        if self.ac_on:
            base += 2.5
        if self.ventilation_on:
            base += 1.2
        if self.lights_on:
            base += 0.8
        base += 0.05 * occupancy  # تأثير عدد الأشخاص
        # شوية noise طبيعي
        return round(base + random.uniform(-0.2, 0.2), 2)
