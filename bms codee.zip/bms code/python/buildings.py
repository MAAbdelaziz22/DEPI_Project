# buildings.py
import math
import random
from datetime import datetime

class Building:
    

    def __init__(self, building_id, b_type, insulation):
        self.id = building_id
        self.type = b_type
        self.insulation = insulation
        self.last_occupancy = 0

    def _occupancy_pattern(self, hour):
        
        
        if self.type == "residential":
            if 6 <= hour < 9:
                return 0.6 + random.uniform(-0.1, 0.1)
            elif 9 <= hour < 17:
                return 0.2 + random.uniform(-0.05, 0.05)
            elif 17 <= hour < 23:
                return 0.9 + random.uniform(-0.1, 0.05)
            else:
                return 0.8 + random.uniform(-0.1, 0.05)

        elif self.type == "office":
            if 8 <= hour < 17:
                return 0.95 + random.uniform(-0.05, 0.02)
            else:
                return 0.05 + random.uniform(0, 0.03)

        elif self.type == "gym":
            if 6 <= hour < 9 or 17 <= hour < 23:
                return 0.85 + random.uniform(-0.05, 0.1)
            else:
                return 0.1 + random.uniform(-0.05, 0.03)

        elif self.type == "mall":
            if 10 <= hour < 22:
                return 0.8 + random.uniform(-0.1, 0.1)
            else:
                return 0.05 + random.uniform(0, 0.02)

        else:
            return 0.3  # default fallback

    def get_occupancy(self, hour, max_people=None):
        
        occ_ratio = self._occupancy_pattern(hour)
        if max_people is None:
            max_people = 50 if self.type != "mall" else 300
        people = int(max_people * occ_ratio)
        self.last_occupancy = people
        return people
