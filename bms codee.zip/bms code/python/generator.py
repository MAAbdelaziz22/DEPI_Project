# generator.py
import time
import random
import csv
import os
from datetime import datetime, timedelta
from config import (
    BUILDINGS, SAMPLE_INTERVAL, CSV_DIR, CSV_MASTER,
    NUM_RECORDS, ANOMALY_PROB, OUTDOOR_ANOMALY_PROB,
    SUMMARY_INTERVAL
)
from utils import ensure_dir, ensure_csv_header, write_row
from sensors import simulate_room_state, outdoor_env
from buildings import Building
from controller import BuildingController
from environment import OutdoorEnvironment
import json
from kafka import KafkaProducer

# Kafka producer
producer = KafkaProducer(
    bootstrap_servers='100.124.244.50:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# CSV header
MASTER_HEADER = [
    "datetime", "day", "month", "year", "building_id", "floor", "room_id",
    "temperature_c", "humidity_pct", "co2_ppm", "light_lux",
    "energy_kw", "occupancy", "ac_on", "vent_on",
    "lights_on", "status", "time_str"
]

LAST_TIME_FILE = os.path.join(CSV_DIR, "last_time.txt")
TIME_STEP = timedelta(seconds=30)  # simulated step

SLEEP_SECONDS = 5  # optional real sleep


def generate(compact=False):
    ensure_dir(CSV_DIR)
    master_path = os.path.join(CSV_DIR, CSV_MASTER)
    ensure_csv_header(master_path, MASTER_HEADER)

    # Prepare building CSVs
    building_files = {}
    for b in BUILDINGS:
        fname = os.path.join(CSV_DIR, f"bms_{b['id']}.csv")
        header = ["datetime", "day", "month", "year"] + MASTER_HEADER[4:]
        ensure_csv_header(fname, header)
        building_files[b['id']] = fname

    # Initialize simulation state
    state = {}
    controllers = {}
    building_objs = {}

    for b in BUILDINGS:
        building_objs[b['id']] = Building(
            b['id'], b['type'], b.get('insulation', 0.75)
        )
        controllers[b['id']] = BuildingController()
        floors = b.get("floors", 1)
        rooms_per = b.get("rooms_per_floor", 1)
        for floor in range(1, floors + 1):
            for room in range(1, rooms_per + 1):
                key = (b['id'], floor, room)
                state[key] = {
                    "temp": 22.0 + random.uniform(-1, 1),
                    "humidity": 50.0 + random.uniform(-3, 3),
                    "co2": 420.0 + random.uniform(-40, 40),
                    "light": 50.0 + random.uniform(-20, 20),
                    "energy": 1.0 + random.uniform(-0.3, 0.3),
                    "ac": False,
                    "vent": False,
                    "lights": False,
                    "occupancy": 0
                }

    # Reconnect Kafka
    global producer
    try:
        producer = KafkaProducer(
            bootstrap_servers='100.124.244.50:9092',
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
        print("✅ Connected to Kafka!")
    except Exception as e:
        print("❌ Kafka connection failed:", e)

    # Load last saved time or start from 29 Nov 2025
    if os.path.exists(LAST_TIME_FILE):
        with open(LAST_TIME_FILE, "r") as f:
            last_time_str = f.read().strip()
            current_time = datetime.fromisoformat(last_time_str)
    else:
        current_time = datetime(2025,1 , 1, 0, 0, 0)

    record_count = 0
    last_summary = time.time()

    print("Starting generation loop...\n")

    while True:
        hour = current_time.hour

        # Outdoor step
        out_anom = random.random() < OUTDOOR_ANOMALY_PROB
        outdoor_temp, outdoor_humidity, outdoor_sunlight = outdoor_env.step(
    current_time, anomaly=out_anom
)


        # Loop buildings → floors → rooms
        for b in BUILDINGS:
            floors = b.get("floors", 1)
            rooms_per = b.get("rooms_per_floor", 1)

            for floor in range(1, floors + 1):
                for room in range(1, rooms_per + 1):
                    key = (b['id'], floor, room)
                    last = state[key]
                    # Occupancy
                    building_obj = building_objs[b['id']]
                    max_people = rooms_per * (15 if b['type'] == "mall" else 5)
                    occ = building_obj.get_occupancy(hour , max_people=max_people)
                    last["occupancy"] = occ

                    # Controller decides
                    controller = controllers[b['id']]
                    controller.decide_controls(
                        last["temp"], last["humidity"], last["co2"],
                        outdoor_sunlight, occ, b['type']
                    )
                    last["ac"] = controller.ac_on
                    last["vent"] = controller.ventilation_on
                    last["lights"] = controller.lights_on

                    # Anomaly
                    anomaly = random.random() < ANOMALY_PROB

                    # Physics simulation
                    new_state = simulate_room_state(last, b, current_time, anomaly=anomaly)

                    # Status
                    alerts = []
                    if new_state["ac"]: alerts.append("AC_ON")
                    if new_state["vent"]: alerts.append("VENT_ON")
                    if new_state["lights"]: alerts.append("LIGHTS_ON")
                    if new_state["energy"] > 6.0: alerts.append("HIGH_ENERGY")
                    if anomaly: alerts.append("ANOMALY")
                    status = "|".join(alerts) if alerts else "NORMAL"

                    # Time fields
                    timestamp = int(current_time.timestamp() * 1000)
                    time_str = current_time.strftime("%I:%M %p")  # hide seconds
                    day_only = current_time.day
                    month_only = current_time.month
                    year_only = current_time.year

                    # MASTER CSV
                    master_row = [
                        timestamp, day_only, month_only, year_only,
                        b['id'], floor, f"R{room}",
                        new_state["temp"], new_state["humidity"],
                        new_state["co2"], new_state["light"],
                        new_state["energy"], new_state["occupancy"],
                        int(new_state["ac"]), int(new_state["vent"]),
                        int(new_state["lights"]), status, time_str
                    ]
                    write_row(master_path, master_row)

                    # BUILDING CSV
                    building_row = [timestamp, day_only, month_only, year_only] + master_row[4:]
                    write_row(building_files[b['id']], building_row)

                    # Update state
                    state[key].update(new_state)

                    # Log
                    print(
                        f"{time_str} | {b['id']}/F{floor}/R{room} | "
                        f"T={new_state['temp']:.2f}C  H={new_state['humidity']:.2f}%  "
                        f"CO2={new_state['co2']:.2f}ppm  L={new_state['light']:.2f}lux "
                        f"E={new_state['energy']:.2f}kW  Occ={new_state['occupancy']} "
                        f"Status={status} | Day={day_only}/{month_only}/{year_only}"
                    )
                    log_file = os.path.join(CSV_DIR, "terminal_log.csv")
                    with open(log_file, "a", newline="") as f:
                     writer = csv.writer(f)
                     writer.writerow([time_str, b['id'], floor, room, new_state['temp'], 
                           new_state['humidity'], new_state['co2'], new_state['light'], 
                           new_state['energy'], new_state['occupancy'], status,
                         f"Day={day_only}/{month_only}/{year_only}"])


                    record_count += 1
                    if NUM_RECORDS and record_count >= NUM_RECORDS:
                        print(f"\nDone: generated {record_count} records.")
                        return

                    # Kafka send
                    producer.send(
                        'bms_data',
                        value={
                            "timestamp": timestamp,
                            "day": day_only,
                            "month": month_only,
                            "year": year_only,
                            "building_id": b['id'],
                            "floor": floor,
                            "room": room,
                            "temperature": new_state["temp"],
                            "humidity": new_state["humidity"],
                            "co2": new_state["co2"],
                            "light": new_state["light"],
                            "energy": new_state["energy"],
                            "occupancy": new_state["occupancy"],
                            "status": status,
                            "time_str": time_str
                        }
                    )

                    # Increment simulated time by 30 seconds per record
                    current_time += TIME_STEP

                    # Save last time safely
                    with open(LAST_TIME_FILE, "w") as f:
                     f.write(current_time.isoformat())
        # Optional real sleep
        time.sleep(SLEEP_SECONDS)

        # Summary
        if time.time() - last_summary >= SUMMARY_INTERVAL:
            summarize(state)
            last_summary = time.time()


def summarize(state):
    total = 0.0
    by_building = {}

    for (bid, floor, room), s in state.items():
        total += s["energy"]
        by_building.setdefault(bid, 0.0)
        by_building[bid] += s["energy"]

    top = sorted(by_building.items(), key=lambda x: x[1], reverse=True)[:5]

    print("\n=== SYSTEM SUMMARY ===")
    print(f"Total estimated energy (kW): {total:.2f}")
    for b, e in top:
        print(f"  {b}: {e:.2f} kW")
    print("======================\n")


print("Starting generator...")
generate()
