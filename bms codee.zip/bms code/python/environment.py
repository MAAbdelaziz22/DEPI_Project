# environment.py
import math
import random
from datetime import datetime

class OutdoorEnvironment:
    """
    Outdoor environment simulator.
    Keeps internal state (last_temp, last_humidity, last_sunlight)
    and provides step(hour, anomaly=False) -> (temp_c, humidity_pct, sunlight_lux)
    """

    def __init__(self, seed_temp=25.0, seed_humidity=50.0, seed_sunlight=300.0):
        self.last_temp = float(seed_temp)
        self.last_humidity = float(seed_humidity)
        self.last_sunlight = float(seed_sunlight)

    def _daily_temp_base(self, hour):
        # low early morning (~4am), peak mid-afternoon (~15:00)
        # returns a smooth base temp; adjust amplitude as needed
        return 18 + 9 * math.sin((hour - 4) * math.pi / 12)

    def _daily_sunlight_base(self, hour):
        # sunlight roughly 0 at night, peaks at noon
        if 6 <= hour <= 18:
            return max(0.0, 1000 * math.sin(((hour - 6) / 12) * math.pi))
        return 0.0

    def step(self, current_dt=None, anomaly=False):
        """
        Advance outdoor state by one step according to given hour (0-23).
        If hour is None, uses current local hour.
        anomaly: if True, create a short spike (heatwave or storm).
        Returns (temp_c, humidity_pct, sunlight_lux)
        """
        if current_dt is None:
            # defensive: if someone passes None accidentally, fallback to real time
            hour = datetime.now().hour
        else:
            hour = current_dt.hour

        # target bases
        base_temp = self._daily_temp_base(hour)
        base_sun = self._daily_sunlight_base(hour)

        # evolve temp toward base slowly + small noise
        self.last_temp += 0.08 * (base_temp - self.last_temp) + random.uniform(-0.2, 0.2)
        # small occasional anomaly spike (heatwave)
        if anomaly:
            self.last_temp += random.uniform(2.5, 6.0)

        # humidity tends to decrease when temp increases (simple model)
        base_humidity = max(10.0, min(90.0, 65 - (self.last_temp - 20) * 0.9))
        self.last_humidity += 0.05 * (base_humidity - self.last_humidity) + random.uniform(-0.5, 0.5)
        if anomaly:
            self.last_humidity += random.uniform(-8.0, 8.0)

        # sunlight evolves toward base
        self.last_sunlight += 0.15 * (base_sun - self.last_sunlight) + random.uniform(-10, 10)
        if anomaly:
            self.last_sunlight += random.uniform(-200, 200)

        # clamp values
        self.last_temp = round(max(-10.0, min(55.0, self.last_temp)), 2)
        self.last_humidity = round(max(1.0, min(99.0, self.last_humidity)), 2)
        self.last_sunlight = round(max(0.0, min(2000.0, self.last_sunlight)), 2)

        return self.last_temp, self.last_humidity, self.last_sunlight

# quick test runner (optional)
from datetime import datetime
env = OutdoorEnvironment()
t, hum, sun = env.step(current_dt=datetime(2025, 1, 1, 14, 0, 0))
print(t, hum, sun)

