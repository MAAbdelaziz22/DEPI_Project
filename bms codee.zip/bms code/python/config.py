# config.py

# Buildings configuration: id, type, floors, rooms per floor, insulation factor (0-1)
BUILDINGS = [
    {"id": "Residential_1", "type": "residential", "floors": 3, "rooms_per_floor": 4, "insulation": 0.75},
    {"id": "Residential_2", "type": "residential", "floors": 3, "rooms_per_floor": 4, "insulation": 0.80},
    {"id": "Residential_3", "type": "residential", "floors": 2, "rooms_per_floor": 3, "insulation": 0.70},
    {"id": "Residential_4", "type": "residential", "floors": 2, "rooms_per_floor": 3, "insulation": 0.72},
    {"id": "Residential_5", "type": "residential", "floors": 3, "rooms_per_floor": 4, "insulation": 0.78},
    {"id": "Residential_6", "type": "residential", "floors": 2, "rooms_per_floor": 2, "insulation": 0.68},
    {"id": "Office_1", "type": "office", "floors": 4, "rooms_per_floor": 8, "insulation": 0.90},
    {"id": "Office_2", "type": "office", "floors": 3, "rooms_per_floor": 6, "insulation": 0.88},
    {"id": "Gym_1", "type": "gym", "floors": 1, "rooms_per_floor": 2, "insulation": 0.60},
    {"id": "Mall_1", "type": "mall", "floors": 2, "rooms_per_floor": 20, "insulation": 0.95},
]

# Sampling interval in seconds (how often generator produces a new batch)
SAMPLE_INTERVAL = 2

# Output config
CSV_DIR = "./bms_output"
CSV_MASTER = "bms_compound_master.csv"

# Number of overall cycles (set None to run forever)
NUM_RECORDS = None

# anomaly probabilities
ANOMALY_PROB = 0.02         # per-reading anomaly
OUTDOOR_ANOMALY_PROB = 0.004

# Summary interval (seconds) to print system summary (optional)
SUMMARY_INTERVAL = 60
