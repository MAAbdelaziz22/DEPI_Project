# ======= File: main.py =======
from generator import generate

if __name__ == "__main__":
    generate()
